/**
 * Created by Kenko on 2014/9/14.
 */

var Constant = {
    CANDY_WIDTH: 64,
    CANDY_TYPE_COUNT: 5,
    MAP_SIZE: 10,
    FALL_ACCELERATION: 30,

    levels:[
        {limitStep:30, targetScore:500},
        {limitStep:25, targetScore:1000},
        {limitStep:20, targetScore:2000},
        {limitStep:20, targetScore:3000},
        {limitStep:15, targetScore:4000},
        {limitStep:10, targetScore:5000}
    ]
};
