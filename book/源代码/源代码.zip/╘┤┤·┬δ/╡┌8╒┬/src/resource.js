
var g_resources = [
    "res/1.png",
    "res/2.png",
    "res/3.png",
    "res/4.png",
    "res/5.png",
    "res/bg.jpg"
];
