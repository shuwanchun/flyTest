var res = {
    bg : "res/bg.jpg",
    item2 : "res/item_2.png",
    item3 : "res/item_3.png"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}