
var g_resources = [
    "res/bg.jpg"
];
