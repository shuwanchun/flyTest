
var g_resources = [
    "res/1.png",
    "res/bg.jpg"
];
