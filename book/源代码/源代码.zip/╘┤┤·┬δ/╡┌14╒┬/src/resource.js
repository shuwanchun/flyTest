
var g_resources = [
    "res/star.png",
    "res/firework.png",
    "res/snow.png",
    "res/texture.png",
    "res/particle.plist",
    "res/fire.png"
];

