
var g_resources = [
    "res/grossini.png",
    "res/mask.png"
];
