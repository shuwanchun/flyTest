
var g_resources = [
    "res/startgame.png",
    "res/startgame2.png",
    "res/startgame3.png",
    "res/font.fnt",
    "res/font.png",
    "res/FirstUI_1/FirstUI_1.json",
    "res/FirstUI_1/bg.jpg",
    "res/FirstUI_1/GUI/button.png",
    "res/FirstUI_1/GUI/selected01.png",
    "res/FirstUI_1/GUI/selected02.png",
];
