
var g_resources = [
    "res/font.fnt",
    "res/font_0.png",
    "res/bm.fnt",
    "res/bm_0.png"
];

