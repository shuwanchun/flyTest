
var g_resources = [
    "res/candy.plist",
    "res/candy.png"
];

