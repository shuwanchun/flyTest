
var g_resources = [
    "res/tile0.png",
    "res/map.tmx",
    "res/tmw_desert_spacing.png"
];
