
var g_resources = [
    "res/bgLayer.jpg",
    "res/bgLayer2.png",
    "res/bgLayer3.png",
    "res/bgLayer4.png"
];
