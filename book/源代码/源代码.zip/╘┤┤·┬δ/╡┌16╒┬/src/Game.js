/**
 * Created by kenkozheng on 2014/8/21.
 * This game is based on the Flash Starling version of Hungry-Hero created by Hsharma, visit http://www.hungryherogame.com
 */

var Game = {

    user:{
        lives:GameConstants.HERO_LIVES,
        score:0,
        distance:0,
        heroSpeed:0,
        coffee:0,
        mushroom:0,
        hitObstacle:0
    },

    gameState:null
};

