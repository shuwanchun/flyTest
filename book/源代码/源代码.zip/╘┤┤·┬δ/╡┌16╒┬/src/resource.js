/**
 * Created by kenkozheng on 2014/8/20.
 */
var g_resources = [
    "res/graphics/texture.plist",
    "res/graphics/texture.png",
    "res/graphics/bgWelcome.jpg",
    "res/graphics/bgLayer.jpg",
    "res/fonts/font.fnt",
    "res/fonts/font.png",
    "res/particles/eat.plist",
    "res/particles/texture.png",
    "res/particles/mushroom.plist",
    "res/particles/coffee.plist",
    "res/particles/wind.plist",
    "res/particles/wind.png"
];
