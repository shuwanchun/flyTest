
var GameScene = cc.Scene.extend({
    onEnter: function () {
        this._super();
        cc.log("version 1.0.2");
    }
});