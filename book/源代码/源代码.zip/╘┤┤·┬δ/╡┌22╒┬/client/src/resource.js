
var g_resources = [
];
