/**
 * Created by Kenko on 2015/1/2.
 */
var jsList = [
    "src/resource.js",
    "src/app.js"
];